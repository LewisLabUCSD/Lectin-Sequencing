# -*- coding: utf-8 -*-
"""
Created on Wed Apr 11 21:22:20 2018

@author: moyja
"""

###### KEY:
    
    # 1: imports
    # 2: time
    # 3: my functions
    # 4: my functions
    # 6: scripts
    # END: major initialization script
        
######

########################################################################################################################

# 1: imports

import collections
import copy
import glob
import glypy as gp
import glypy.plot as gpp
import itertools as it
import math
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import numpy.random as nra
import numpy.linalg as nla
import pandas as pd
import pickle as pk
import re
import random as ra
import scipy as sp
import scipy.integrate as sig
import scipy.linalg as sla
import scipy.optimize as sop
import scipy.sparse as sps
import sys
import time

from collections import Counter
from copy import deepcopy
from matplotlib.pyplot import plot
from numpy import (angle, arange, arccos, array, arcsin, arctan, arctan2, argmax, argmin, argsort,
                   concatenate, conj, cos, cosh, diag, e, einsum, exp, eye, imag, ix_, kron,
                   linspace, log, logspace, mean, ones, pi, real, sin, sinh, sqrt, std,
                   tan, tanh, trace, zeros)
from numpy.linalg import norm
from numpy.random import rand, randint, randn
from scipy.linalg import null_space, orth, sqrtm
from scipy.sparse import csr_matrix as sparse, diags, eye as speye, kron as sparkron
from scipy.special import logsumexp

########################################################################################################################

# 2: time stuff

MY_TIMES = {'yommytime':time.time()}

def clockface(seconds):
    seconds = int(seconds)
    hours = seconds//3600
    seconds -= 3600 * hours
    minutes = seconds//60
    seconds -= 60 * minutes
    houstr = str(hours)
    minstr = str(minutes)
    secstr = str(seconds)
    if seconds <= 9:
        secstr = '0' + secstr
    if minutes <= 9:
        minstr = '0' + minstr
    if hours == 0:
        if minutes == 0:
            if seconds == 0:
                return ''
            else:
                return str(seconds)
        else:
            return str(minutes) + ':' + secstr
    else:
        return houstr + ':' + minstr + ':' + secstr
        
def prog_bar(a, T, bartype = 'arrow', barname = 'pbar', savetime = True):
    # this burns about 3 seconds / 10,000 calls without savetime, with it no problem up to 1,000,000 
    # note that a must be zero to start
    if a == 0:
        tic(name = barname)
        print()
    else:
        if savetime and a != T-1:
            divider = T//1000 + 1
            if a % divider != 0:
                return
        progress = a/T
        elapsed = toc(out_state = 1, name = barname)
        remaining = (T/a-1)*elapsed
        if bartype == 'arrow':
            L = 60
            point = int(L*progress)
            mytime = clockface(elapsed)
            bar = ' '*(7-len(mytime)) + mytime + '  '
            if a == T-1:
                print('\r' + bar + 'X' + ' '*(L-4) + chr(187) + '--X' + clockface(remaining) + '    \n')
            else: 
                if point >= 4:
                    bar += '>' + ' '*(point-4) + chr(187) + '-->' + ' '*(L-1-point) + '<'
                elif point == 3:
                    bar += '>' + '-->' + ' '*(L-4) + '<'
                elif point == 2:
                    bar += '>' + '->' + ' '*(L-3) + '<'
                elif point == 1:
                    bar += '>' + '>' + ' '*(L-2) + '<'
                elif point == 0:
                    bar += '>' + ' '*(L-1) + '<'
                print('\r' + bar + '  ' + clockface(remaining) + '    ', end ='\r')
        if bartype == 'simple':
            if a == T-1:
                print('\r' + barname + ': 100% at t = ',int(toc(1)),'                       ')
            else:
                print('\r' + barname + ': ' + str(int(100*progress)) + '% with t = ' + str(int(remaining)) + ' remaining            ', end ='\r')

def tic(out_state = 0, name = 'yommytime'):
    # out_state = 0 if silent, 1 if returning elapsed time, 2 if printing elapsed time
    global MY_TIMES
    if out_state == 0:
        MY_TIMES[name] = time.time()
    elif out_state == 1:
        hold = MY_TIMES[name]
        MY_TIMES[name] = time.time()
        return MY_TIMES[name] - hold
    elif out_state == 2:
        hold = MY_TIMES[name]
        MY_TIMES[name] = time.time()
        print('TIME: ', name, ' :  delta  = ', MY_TIMES[name] - hold)
    else:
        raise Exception('unidentified outstate')
        

def toc(out_state = 2, name = 'yommytime'):
    # out_state = 0 if silent, 1 if returning elapsed time, 2 if printing elapsed time
    if out_state == 1:
        return(time.time() - MY_TIMES[name])
    elif out_state == 2:
        print('TIME: ', name, ' = ', time.time() - MY_TIMES[name])
    else:
        raise Exception('unidentified outstate')
        
########################################################################################################################

# 3: funky fucks

def entropy(somelist):
    # need not be normalized
    somelist = array(somelist)
    if np.any(somelist < 0):
        raise Exception('negative in prob array')
        
    tote = np.sum(somelist)
    probs = somelist/tote
    probs = probs + (probs == 0)
    return - np.sum(probs*log(probs))
    

def hcat(*mats):
    return(np.concatenate(mats,axis = 1))

def isvec(nparr):
    # this will return True if array is 1d, even if it is 1x1
    # something strange might happen if a dimension is zero
    flag = False
    for dim in nparr.shape:
        if dim != 1:
            if flag:
                return False
            else:
                flag = True
    return True

def rand_prob(d):
    pows = np.concatenate([1 - nra.power(range(d-1,1,-1)), rand(1)])
    remains = 1
    for a in range(d-1):
        pows[a] *= remains
        remains -= pows[a]
    return np.concatenate([pows, array([1-np.sum(pows)])])

def vcat(*mats):
    return(np.concatenate(mats,axis = 0))

########################################################################################################################

# 4: MY things

class hash_counter(collections.Counter):
    def __hash__(self):
        return hash(tuple(sorted(self.elements())))
    
class hash_dict(dict):
    def __hash__(self):
        return hash(tuple(sorted(self.items())))

def my_choice(stuff, p = None):
    if type(stuff) == list or type(stuff) == tuple:
        index = nra.choice(len(stuff), p = p)
        return stuff[index]
    elif type(stuff) == np.ndarray:
        N = np.prod(stuff.shape)
        if p == None:
            return nra.choice(stuff.reshape(N))
        elif stuff.shape == p.shape:
            return nra.choice(stuff.reshape(N), p = p.reshape(N))
        else:
            raise Exception('stuff : p mismatch')
    else:
        raise Exception('unrecognized type')

def my_csv(data, name):
    # creates csv with name filename.csv
    np.savetxt(name + '.csv', data, delimiter = ', ', fmt ='% s')

def my_dump(cucumber, name):
    # saves file with name name.p
    file = open(name + '.p', 'wb')
    pk.dump(cucumber, file)
    file.close()

def my_hist(stuff, label = None, axis = None):
    # stuff = a list of numbers
    # returns nothing, plots histogram of stuff with my fav binning
    if axis is None:
        plt.hist(stuff, bins = int(len(stuff)**0.5), histtype = 'step', label = label)
    else:
        axis.hist(stuff, bins = int(len(stuff)**0.5), histtype = 'step', label = label)

def my_kron(*mats):
    # I,B --> B 0
    #         0 B (big dimensions first)
    # I think it's better to put the little matrices first
    hold = mats[len(mats)-1]
    for a in range(len(mats)-2,-1,-1):
        hold = kron(mats[a],hold)
    return(hold)

def my_load(filename):
    file = open(filename, 'rb')
    obj = pk.load(file)
    file.close()
    return obj

def my_outer(a, b = None):
    # returns |a><b|
    if b == None :
        b = a
    return(np.outer(a,b.conj()))

def my_spar_kron(*mats):
    hold = mats[len(mats)-1]
    for a in range(len(mats)-2,-1,-1):
        hold = sps.kron(mats[a],hold)
    return(hold)
    
########################################################################################################################



########################################################################################################################


    

    
        
########################################################################################################################


########################################################################################################################

# translating things and drawings

def cfg2tree(stringz):
    # strings = string or list of strings from cfg array
    # Ex:  Gala1-3(Fuca1-2)Galb1-3GlcNAcb-Sp8
    # returns nx graph or list of nx graphs
    if type(stringz) == str:
        stringz = [stringz]
    
    glycans = []
    for strang in stringz:
        tokenz = re.split(r'(\(|\)|[ab]\d-\d|[ab]-|-)', strang)
        
        mytree = nx.DiGraph()
        mytree.add_node(0, name = tokenz.pop())
        
        mylink = ''
        node_hold = [0]
        state = 2
        # 1 = got link, looking for node.
        # 2 = got node, looking for link.
        for token in reversed(tokenz):
            if token == '':
                continue
            elif token == ')':
                node_hold.append(node_hold[-1])
            elif token == '(':
                node_hold.pop()
            elif state == 1:
                newnode = rand()
                mytree.add_node(newnode, name = token)
                mytree.add_edge(node_hold[-1], newnode, name = mylink)
                node_hold[-1] = newnode
                state = 2
            elif state == 2:
                mylink = token
                state = 1
        glycans.append(mytree)
                    
    if len(glycans) == 1:
        return glycans[0]
    else:
        return glycans

def draw_graph(g, edgenames = False):
    def splitr(x, y, n, graph, record):
        record[n] = (x,y)
        flag = False
        for child in graph[n]:
            if flag:
                y += 1
            else:
                flag = True
            y = splitr(x+1, y, child, graph, record)
        return y
    names = {mynode : g.nodes[mynode]['name'] for mynode in g.nodes}
    myroot = 0
    rec = {}
    splitr(0, 0, myroot, g, rec)
    
    nx.draw(g, rec, labels = names, node_color = 'white', node_size = 600)
    if edgenames:
        nx.draw_networkx_edge_labels(g, rec, edge_labels = {ed : g.edges[ed]['name'] for ed in g.edges})
    plt.show()

def gpimg(tree, axis = None, label = False):
    tree = nx2gp(tree)
    gp.plot.plot(tree, ax = axis, center = True, label = label)
    
def graph2iupac(tree):
    def crawl(node, g):
        kids = list(g[node])
        if len(kids) == 0:
            
            return g.nodes[node]['name']
        else:
            mystr = crawl(kids[0],g) + '(' + g.edges[node,kids[0]]['name'] + ')'
            for a in range(1,len(kids)):
                mystr += '[' + crawl(kids[a],g) + '(' + g.edges[node,kids[a]]['name'] + ')' + ']'
            return mystr + g.nodes[node]['name']
    if tree.nodes[0]['name'] != 'Asn':
        raise Exception('root is not asn')
    
    return crawl(0,tree)


def nx2gp(tree):
    def crawl(tree, node, mono):
        for kid in tree[node]:
            sug = tree.nodes[kid]['name']
            if sug == 'end':
                return
            else:
                new_mono = monos[sug]
                mono.add_monosaccharide(new_mono)
                crawl(tree, kid, new_mono)
    monos = gp.monosaccharides
    sug1 = list(tree[0])[0]
    mono1 = monos[tree.nodes[sug1]['name']]
    crawl(tree, sug1, mono1)
    return gp.Glycan(root = mono1)
    

def str2graph(mystr):
    L = len(mystr)
    g = nx.DiGraph()
    g.add_node(0, name = 'Asn')
    edge_hold = ';'
    node_hold = [0]
    pos = L-6
    back = L-6
    
    if mystr[-6:] != ");Asn'":
        raise Exception('string format?')
    
    while pos > 0:
        pos -= 1
        while pos > 0 and mystr[pos].isalpha():
            pos -= 1
        else:
            g.add_node(pos + 1, name = mystr[pos + 1 : back])
            g.add_edge(node_hold[-1], pos + 1, name = edge_hold)
            node_hold[-1] = pos + 1
            
            if mystr[pos] == ')':
                node_hold.append(pos+1)
                pos -= 1
            elif mystr[pos] == '(':
                node_hold.pop()
                pos -= 1
            
            if mystr[pos].isdigit():
                if mystr[pos-2].isdigit():
                    edge_hold = mystr[pos-2 : pos+1]
                    back = pos - 2
                    pos -= 2
                else:
                    edge_hold = mystr[pos-1 : pos+1]
                    back = pos - 1
                    pos -= 1
            else:
                return g

def trans_tree_lin2iupac(forest):
    # currently only translating nodes
    # returns a translated copy.
    def trans(token):
        if token == 'Asn':
            return 'root'
        elif token == 'root':
            return 'root'
        elif token == 'A':
            return 'Gal'
        elif token == 'HxN':
            return 'HexNAc'
        elif token == 'GN':
            return 'GlcNAc'
        elif token == 'NN':
            return 'NeuAc'
        elif token == 'M':
            return 'Man'
        elif token == 'F':
            return 'Fuc'
        else:
            raise Exception('sugar unknown: ' + token)
            
    if type(forest) == nx.DiGraph:
        forest = [forest]
    forest = deepcopy(forest)
    
    for tree in forest:
        for node in tree:
            tree.nodes[node]['name'] = trans(tree.nodes[node]['name'])
            
    if len(forest) == 1:
        return forest[0]
    else:
        return forest
    
def trans2iupac(strings):
    def trans(token):
        if type(token) != str:
            raise Exception('fake token')
        
        if( token == '[' or token == ']' or token == '(' or token == ')' 
           or token == ';' or token == '' ):
            return token
        
        elif token[0] == 'a' or token[0] == 'b':
            # must be link
            if len(token) == 1:
                return token[0] + '1-?'
            elif len(token) == 2 and token[1].isdigit():
                return token[0] + '1-' + token[1]
            elif len(token) == 3 and token[1] == '1' and token[2].isdigit():
                return token[0] + '1-' + token[2]
            elif len(token) == 4 and token[1:3] == '1-' and token[3].isdigit():
                return token[0] + '1-' + token[3]
            else:
                raise Exception('deze some nasty hookups: ' + token)
        else:
            # must be sugar
            if token == 'A':
                return 'Gal'
            elif token == 'HxN':
                return 'HexNAc'
            elif token == 'GN':
                return 'GlcNAc'
            elif token == 'NN':
                return 'NeuAc'
            elif token == 'Gal':
                return 'Gal'
            elif token == 'M':
                return 'Man'
            elif token == 'F':
                return 'Fuc'
            else:
                raise Exception('sugar unknown: ' + token)
    newstrings = []
    for s in strings:
        if s[-6:] == '(;)Asn':
            s = s[:-6]
        else:
            raise Exception('doesnt end in (;)Asn')
        mysplit = [trans(tok) for tok in re.split(r'([\[\]\(\)])', s)]
        newstrings.append(''.join(mysplit))
    return newstrings

def tree2img(g, edgenames = False):
    names = {mynode : g.nodes[mynode]['name'] for mynode in g.nodes}
    node2point = {}
    parents = [0]
    x = 0
    while len(parents) > 0:
        for i, p in enumerate(parents):
            node2point[p] = (x, i - (len(parents)-1)/2 )
        parents = [ kid for p in parents for kid in g[p] ]
        x += 1
    nx.draw(g, node2point, labels = names, node_color = 'white', node_size = 600)
    plt.show()

########################################################################################################################

# 5: major initialization script

np.set_printoptions(precision = 3, suppress = True, linewidth = 80, edgeitems = 4)

fake_glycans = my_load('fake_glycans.p')
reel_glycans = my_load('reel_glycans.p')
reel_iupac = my_load('reel_iupac.p')
glycan_set_2 = my_load('glycan_set_2.p')
glycan_set_2_tags = my_load('glycan_set_2_tags.p')
all_reelz = my_load('all_reelz.p')
all_iupac = my_load('all_iupac.p')
cfg_data = my_load('doctored_cfg_600.p')
bigcfgs = []
for tree in cfg_data:
    if len(tree) > 5:
        bigcfgs.append(tree)
pnames, ptrees, profiles = my_load('profiles.p')

bojar_filenames, bojar_avgs, bojar_stds = my_load('bojar_raw_data.p')

rawcfgs = np.genfromtxt('cfgmam5glycans.csv', delimiter = ',', dtype = str)
cfg5_ids = []
cfg5_trees = []
cfg5_cut_trees = []
chosenbos = []
bojar_selected_means = []
bojar_selected_stds = []
for i, mystr in enumerate(rawcfgs):
    if mystr != 'x':
        cfg5_ids.append(i+1)
        tree = cfg2tree(str(mystr))
        cfg5_trees.append(tree)
        cut_tree = deepcopy(tree)
        firstguy = list(cut_tree[0])[0]
        cut_tree.nodes[0]['name'] = 'root'
        cut_tree.edges[0, firstguy]['name'] = ';'
        cfg5_cut_trees.append(cut_tree)
        bojar_selected_means.append(bojar_avgs[:,i])
        bojar_selected_stds.append(bojar_stds[:,i])
bojar_selected_means = array(bojar_selected_means).T
bojar_selected_stds = array(bojar_selected_stds).T
bojar_selected_normalized_means = bojar_selected_means / np.max(bojar_selected_means, axis = 1).reshape(bojar_selected_means.shape[0],1)
bojar_selected_normalized_stds = bojar_selected_stds * bojar_selected_normalized_means / bojar_selected_means

for tree in cfg5_cut_trees:
    mynodes = list(tree)
    for node in mynodes:
        if len(tree[node]) == 0:
            newnode = rand()
            tree.add_edge(node, newnode, name = ';')
            tree.nodes[newnode]['name'] = 'end'

cfg5_cut_nolink_trees = deepcopy(cfg5_cut_trees)
for tree in cfg5_cut_nolink_trees:
    for edge in tree.edges:
        tree.edges[edge]['name'] = ';'
        
def getter():
    nodes = []
    links = []
    spacers = []
    myls = []
    guy = np.genfromtxt('cfgmam5glycans.csv', delimiter = ',', dtype = str)
    for mystr in guy:
        first = True
        mylist = re.split(r'([ab]\d-\d|b1-|[ab]-|-|\)|\()',mystr)
        myls.append(mylist)
        for thing in mylist:
            if first:
                nodes.append(thing)
                first = False
            else:
                links.append(thing)
                first = True
        spacers.append(nodes.pop())
    print(dict(Counter(nodes)))
    print(dict(Counter(links)))
    print(dict(Counter(spacers)))
    return myls

########################################################################################################################

# finalizing shit

def get_link_flow(forest):
    # forest = tree or tree list
    # returns {link1: { (future link tuple) : probability of future } }
    if type(forest) == nx.DiGraph:
        forest = [forest]
        
    myflows = {}
    for tree in forest:
        for edge in tree.edges:
            cnode = edge[1]
            sug1 = tree.nodes[edge[0]]['name']
            link = tree.edges[edge]['name']
            sug2 = tree.nodes[cnode]['name']
            link1 = (sug1, link, sug2)
            if link1 not in myflows:
                myflows[link1] = {}
            future = hash_counter((sug2, tree.edges[cnode, kid]['name'], tree.nodes[kid]['name'])
                           for kid in tree[cnode])
            if future in myflows[link1]:
                myflows[link1][future] += 1
            else:
                myflows[link1][future] = 1
    
    for dic in myflows.values():
        tot = sum(dic.values())
        for guy in dic:
            dic[guy] /= tot
    
    return myflows  

def get_links(forest):
    if type(forest) == nx.DiGraph:
        forest = [forest]
    mylinks = set()
    for tree in forest:
        for edge in tree.edges:
            sug1 = tree.nodes[edge[0]]['name']
            link = tree.edges[edge]['name']
            sug2 = tree.nodes[edge[1]]['name']
            mylinks.add((sug1, link, sug2))
    return list(mylinks)

def get_motif_vector(forest, motif_list, mode = 'single'):
    if type(motif_list) != list and type(motif_list) != tuple:
        raise Exception('motif list is not list')
    if type(forest) == nx.DiGraph:
        forest = [forest]
    
    F = len(forest)
    L = len(motif_list)
    motif_tsil = {motif_list[i] : i for i in range(L)}
    
    motif_vectors = zeros((L,F))
    for a, tree in enumerate(forest):
        for edge in tree.edges():
            cnode = edge[1]
            sug1 = tree.nodes[edge[0]]['name']
            link = tree.edges[edge]['name']
            sug2 = tree.nodes[cnode]['name']
            if sug2 != 'end':
                link1 = (sug1, link, sug2)
                future = hash_counter((sug2, tree.edges[cnode, kid]['name'], tree.nodes[kid]['name'])
                               for kid in tree[cnode])
                motif = (link1, future)
                if motif in motif_tsil:
                    motif_vectors[motif_tsil[motif],a] += 1
                else:
                    pass # normally id raise a ruckus, but this is by design
    if mode == 'single':
        return np.sum(motif_vectors, axis = 1)
    elif mode == 'multi':
        return motif_vectors
    else:
        raise Exception('modality')

def get_motif_xpex(start_probs, link_flow, motif_list):
    # link flow in, but motif flow is a matrix
    # must be probability flow
    # returns = start motif vector, motif expectation flow
    M = len(motif_list)
    motif_tsil = {motif_list[i] : i for i in range(M)}
    
    start_vec = zeros(M)
    for slink, p in start_probs.items():
        for fut, q in link_flow[slink].items():
            start_vec[motif_tsil[(slink,fut)]] += p*q
    
    xmat = zeros((M,M))
    for i, mo1 in enumerate(motif_list):
        futlinks = mo1[1]
        for link in futlinks.elements():
            if link[2] != 'end':
                furfuts = link_flow[link]
                for ff, p in furfuts.items():
                    xmat[motif_tsil[(link,ff)],motif_tsil[mo1]] += p
    
    vals, vecx = nla.eig(xmat)
    for v in vals:
        if abs(v) >= 1:
            raise Exception('eigenvalue >= 1')
    
    end_vec = nla.lstsq(eye(M) - xmat, start_vec)[0]
    
    return start_vec, xmat, end_vec

def get_motifs(forest, forme = 'list'):
    # a motif is simply a (link, (futurelinks) ) pair
    # returns {motif: count} or [motifs]
    # does not return terminal guyz
    if type(forest) == nx.DiGraph:
        forest = [forest]

    motifs = {}
    for tree in forest:
        for edge in tree.edges:
            cnode = edge[1]
            sug1 = tree.nodes[edge[0]]['name']
            link = tree.edges[edge]['name']
            sug2 = tree.nodes[cnode]['name']
            link1 = (sug1, link, sug2)
            future = hash_counter((sug2, tree.edges[cnode, kid]['name'], tree.nodes[kid]['name'])
                           for kid in tree[cnode])
            if len(future) > 0:
                motif = (link1, future)
                if motif in motifs:
                    motifs[motif] += 1
                else:
                    motifs[motif] = 1
    if forme == 'list':
        return list(motifs)
    elif forme == 'dict':
        return motifs    
    
def get_start_link_probs(forest):    
    if type(forest) != list:
        raise Exception('forest is not a list')
    F = len(forest)
    
    start_probs = {}
    for tree in forest:
        start = tree.nodes[0]['name']
        if start != 'root':
            #raise Exception('root not at zero')
            print('WARNING: 0 != root')
        sug = list(tree[0])
        if len(sug) != 1:
            raise Exception('split root')
        sug = sug[0]
        link = tree.edges[0,sug]['name']
        if link != ';':
            #raise Exception('first link not ;')
            print('WARNING: first link not ;')
        starlin = (start, link, tree.nodes[sug]['name'])
        if starlin in start_probs:
            start_probs[starlin] += 1/F
        else:
            start_probs[starlin] = 1/F
    
    return start_probs

def get_stuff(forest):
    link_list = get_links(forest)
    L = len(link_list)
    link_tsil = {link_list[i] : i for i in range(L)}
    link_flow = get_link_flow(forest)
    index_flow = link2index_flow(link_list, link_flow)
    start_probs = get_start_link_probs(forest)
    
    motif_list = get_motifs(forest)
    M = len(motif_list)
    motif_tsil = {motif_list[i] : i for i in range(M)}
    
    return link_list, link_tsil, start_probs, link_flow, index_flow, motif_list, motif_tsil

def graphs_equal(tree1, tree2):
    # trees must start zero
    def check(node1, node2):
        kidict1 = { (tree1.nodes[kid]['name'], tree1.edges[node1, kid]['name']) : kid
                   for kid in tree1[node1] }
        kidict2 = { (tree2.nodes[kid]['name'], tree2.edges[node2, kid]['name']) : kid
                   for kid in tree2[node2] }
        if Counter(kidict1.keys()) == Counter(kidict2.keys()):
            for minilink in kidict1.keys():
                if not check( kidict1[minilink], kidict2[minilink] ):
                    return False
            else:
                return True
        else:
            return False
    
    if tree1.nodes[0]['name'] == tree2.nodes[0]['name']:
        return check(0,0)
    else:
        return False

def link2index_flow(link_list, linkflow):
    # note that there are log(p) not probabilities
    
    L = len(link_list)
    link_tsil = {link_list[i] : i for i in range(L)}
    index_flow = ['error']*L
    for link1, mydic in linkflow.items():
        index_flow[link_tsil[link1]] = { hash_counter(link_tsil[link2] for link2 in future) : log(p)
                                        for future, p in mydic.items() }
    return index_flow

def motif_indexer(link_list, motif_list):
    # returns indexer array[]
    L = len(link_list)
    link_tsil = {link_list[i] : i for i in range(L)}
    indexer = [{} for a in range(L)]
    count = 0
    for i, mo in enumerate(motif_list):
        count += 1
        future_dex = hash_counter(link_tsil[link] for link in mo[1])
        indexer[link_tsil[mo[0]]][future_dex] = i
    return indexer

def sample_trees(start, flow, N = 0):
    # flow = link flow
    # N = number of samples
    def grow(tree, node, link, flow, height):
        # grows tree, will modify input!
        # node = where we will grow out
        # parsug = name of parent sugar
        # flow = the PRETTY link flow, not the motif
        CEILING = 30
        if height < CEILING: 
            futures, probs = zip(*flow[link].items())
            fut = my_choice(futures, p = probs)
            for newlink in fut.elements():
                newnode = rand()
                tree.add_node(newnode, name = newlink[2])
                tree.add_edge(node, newnode, name = newlink[1])
                grow(tree, newnode, newlink, flow, height + 1)
        else:
            raise Exception('hit tree size ceiling, prolly not good but maybe fine')
    
    if N == 0:
        tree = nx.DiGraph()
        node = rand()
        choice = my_choice(*zip(*start.items()))
        tree.add_edge(0,node, name = choice[1])
        tree.nodes[0]['name'] = choice[0]
        tree.nodes[node]['name'] = choice[2]
        grow(tree, node, choice, flow, 0)
        return tree
    else:
        samples = [nx.DiGraph() for a in range(N)]
        for a, tree in enumerate(samples):
            node = rand()
            choice = my_choice(*zip(*start.items()))
            tree.add_edge(0,node, name = choice[1])
            tree.nodes[0]['name'] = choice[0]
            tree.nodes[node]['name'] = choice[2]
            grow(tree, node, choice, flow, 0)
        return samples

########################################################################################################################

def dumb_sampling(lectarz, forest, mu, std_vec, N):
    # returns matrix of lil_proxy column vectors for each lectar
    if len(lectarz.shape) == 1:
        lectarz = lectarz.reshape(L,1)
    L, G = lectarz.shape
    motifs = get_motifs(forest)
    flow = get_link_flow(forest)
    start = get_start_link_probs(forest)
    mytrees = sample_trees(start, flow, N)
    movex = get_motif_vector(mytrees, motifs, mode = 'multi')
    
    mu = mu / std_vec.reshape(L,1)  # the only parts where sigma comes in
    lectarz = lectarz / std_vec.reshape(L,1) # the only parts where sigma comes in
    diffs = mu.dot(movex).reshape(L,N,1) - lectarz.reshape(L,1,G)
    lil_proxy = -np.sum(diffs**2, axis = 0)
    
    #mytrees, lil_proxy = zip(*sorted(zip(mytrees, lil_proxy), key = lambda x: -x[1]))
    
    return mytrees, lil_proxy
    
def stoopid_info(forest, bindings, N, T):
    # forest = list of G input glycans in nx form
    # bindings = lectin binding array L x G
    # N = number of targets
    # T = number of samples
    # returns markov true entropy, forest entropy, lectin profile entropy, motif vector entropy
    tic()
    SMALL = 10**-5
    L, G = bindings.shape
    motifs = get_motifs(forest)
    M = len(motifs)
    flow = get_link_flow(forest)
    start = get_start_link_probs(forest)
    movex = get_motif_vector(forest, motifs, mode = 'multi')
    mu, std_vec = fit2(movex, bindings)
    
    tar_trees = sample_trees(start, flow, N)
    tar_movex = get_motif_vector(tar_trees, motifs, mode = 'multi')
    lectarz = mu.dot(tar_movex) + randn(L,N) * std_vec.reshape(L,1)
    sham_trees = sample_trees(start, flow, T)
    sham_movex = get_motif_vector(sham_trees, motifs, mode = 'multi')
    
    toc()
    print('removing duplicates...')
    
    sham_tree_counts = {}
    exindex = []
    for i, tree1 in enumerate(sham_trees):
        prog_bar(i, T)
        for tree2 in sham_tree_counts:
            if graphs_equal(tree1, tree2):
                sham_tree_counts[tree2] += 1
                break
        else:
            sham_tree_counts[tree1] = 1
            exindex.append(i)
    
    sham_movex = sham_movex[:,exindex]
    sham_trees, sham_tree_counts = zip(*sham_tree_counts.items())
    sham_tree_counts = array(sham_tree_counts)
    T = len(sham_trees)
    
    toc()
    
    motif_matching = zeros((T,N))
    for a in range(N):
        prog_bar(a,N)
        motif_matching[:,a] = np.prod(sham_movex == tar_movex[:,a].reshape(M,1), axis = 0)
    
    toc()
    
    lil_proxies = zeros((T,N))
    mux = mu.dot(sham_movex) / std_vec.reshape(L,1)
    lectarz = lectarz / std_vec.reshape(L,1)
    for a in range(N):
        prog_bar(a,N)
        lil_proxies[:,a] = - np.sum( (mux - lectarz[:,a].reshape(L,1))**2, axis = 0 )
        
    toc()
    #np.prod( sham_movex.reshape(M,N,1) == sham_movex.reshape(M,1,N), axis = 0 )
    #lil_proxies = -np.einsum( 'i,ijk', 1/std_vec**2,
    #                         ( mu.dot(sham_movex).reshape(L,N,1) - sham_tarz.reshape(L,1,N) )**2 )
    
    motif_probs = motif_matching * sham_tree_counts.reshape(T,1)
    motif_probs = motif_probs / np.sum(motif_probs, axis = 0)
    lectin_probs = exp(lil_proxies - np.max(lil_proxies, axis = 0))
    lectin_probs = lectin_probs * sham_tree_counts.reshape(T,1)
    lectin_probs = lectin_probs / np.sum(lectin_probs, axis = 0)
    
    #np.fill_diagonal(motif_matching, zeros(N))
    #np.fill_diagonal(match_probs, zeros(N))
    
    S_markov = swaggy_entropy(start, flow)
    S_f = entropy(sham_tree_counts)
    S_m = [entropy(motif_probs[:,a]) for a in range(N)]
    S_l = [entropy(lectin_probs[:,a]) for a in range(N)]
    
    toc()
    return S_markov,  S_f,  S_l,  S_m

def stoopid_info_2(forest, bindings, N, T):
    # forest = list of G input glycans in nx form
    # bindings = lectin binding array L x G
    # N = number of targets
    # T = number of samples
    # returns markov true entropy, forest entropy, lectin profile entropy, motif vector entropy
    tic()
    SMALL = 10**-5
    L, G = bindings.shape
    motifs = get_motifs(forest)
    M = len(motifs)
    flow = get_link_flow(forest)
    start = get_start_link_probs(forest)
    movex = get_motif_vector(forest, motifs, mode = 'multi')
    mu, std_vec = fit2(movex, bindings)
    
    tar_trees = sample_trees(start, flow, N)
    tar_movex = get_motif_vector(tar_trees, motifs, mode = 'multi')
    lectarz = mu.dot(tar_movex) + randn(L,N) * std_vec.reshape(L,1)
    sham_trees = sample_trees(start, flow, T)
    sham_movex = get_motif_vector(sham_trees, motifs, mode = 'multi')
    
    toc()
    print('removing duplicate trees...')
    
    sham_tree_counts = {}
    exindex = []
    for i, tree1 in enumerate(sham_trees):
        prog_bar(i, T)
        for tree2 in sham_tree_counts:
            if graphs_equal(tree1, tree2):
                sham_tree_counts[tree2] += 1
                break
        else:
            sham_tree_counts[tree1] = 1
            exindex.append(i)

    sham_trees, sham_tree_counts = zip(*sham_tree_counts.items())
    sham_tree_counts = array(sham_tree_counts)
    sham_movex = sham_movex[:,exindex]
    T = len(sham_trees)
    
    toc()
    print('removing duplicate movex...')
    
    movec_counts = {}
    i = 0
    V = T
    while i < V:
        prog_bar(i, T)
        np.all(movex == movec[:,a].reshape(M,1), axis = 0)
        for tree2 in sham_tree_counts:
            if graphs_equal(tree1, tree2):
                sham_tree_counts[tree2] += 1
                break
        else:
            sham_tree_counts[tree1] = 1
            exindex.append(i)
    motif_matching = zeros((T,N))
    for a in range(N):
        prog_bar(a,N)
        motif_matching[:,a] = np.prod(sham_movex == tar_movex[:,a].reshape(M,1), axis = 0)
    
    toc()
    
    lil_proxies = zeros((T,N))
    mux = mu.dot(sham_movex) / std_vec.reshape(L,1)
    lectarz = lectarz / std_vec.reshape(L,1)
    for a in range(N):
        prog_bar(a,N)
        lil_proxies[:,a] = - np.sum( (mux - lectarz[:,a].reshape(L,1))**2, axis = 0 )
        
    toc()
    #np.prod( sham_movex.reshape(M,N,1) == sham_movex.reshape(M,1,N), axis = 0 )
    #lil_proxies = -np.einsum( 'i,ijk', 1/std_vec**2,
    #                         ( mu.dot(sham_movex).reshape(L,N,1) - sham_tarz.reshape(L,1,N) )**2 )
    
    motif_probs = motif_matching * sham_tree_counts.reshape(T,1)
    motif_probs = motif_probs / np.sum(motif_probs, axis = 0)
    lectin_probs = exp(lil_proxies - np.max(lil_proxies, axis = 0))
    lectin_probs = lectin_probs * sham_tree_counts.reshape(T,1)
    lectin_probs = lectin_probs / np.sum(lectin_probs, axis = 0)
    
    #np.fill_diagonal(motif_matching, zeros(N))
    #np.fill_diagonal(match_probs, zeros(N))
    
    S_markov = swaggy_entropy(start, flow)
    S_f = entropy(sham_tree_counts)
    S_m = [entropy(motif_probs[:,a]) for a in range(N)]
    S_l = [entropy(lectin_probs[:,a]) for a in range(N)]
    
    toc()
    return S_markov,  S_f,  S_l,  S_m


########################################################################################################################

def fit1(movex, lectarz, T):
    # for a SINGLE LECTIN
    # movex = M x G 
    # lectarz = G long array of lectin readouts
    # this goddam thing just wont optimize!
    def cost_fun(sigmas):
        # sigmas = M long stds NOT variances
        sigma_vec = sigmas.dot(movex)
        normed_movex = movex / sigma_vec
        normed_lectarz = lectarz / sigma_vec
        mu =  sop.nnls(normed_movex.T, normed_lectarz)[0]
        logpart = log(sigma_vec**2)
        quadpart = (mu.dot(movex) - lectarz)**2
        print(np.sum(logpart + quadpart))
        return np.sum(logpart + quadpart)
    
    M, G = movex.shape
    if len(lectarz.shape) != 1 or len(lectarz) != G:
        raise Exception(' lectarz shape mismatch')
        
    sigma_seed = ones(M)
    thing = sop.minimize(lambda s: cost_fun(s), sigma_seed, options = {'maxiter' : T}) # wont minimize...
    
    return thing

def fit2(movex, lectarz):
    # TAKING ALL LECTINS! not just one
    # movex = M x G
    # lectarz = L x G
    # returns mu, std_vec = L vector of standard deviations
    M, G = movex.shape
    L, G = lectarz.shape
    if movex.shape[1] != G:
        raise Exception(' movex shape mismatch')
        
    mu = zeros((L,M))
    for a in range(L):
        prog_bar(a,L)
        mu[a,:] = sop.nnls(movex.T, lectarz[a,:])[0]
    
    diffs = mu.dot(movex) - lectarz
    std_vec = np.mean(diffs**2, axis = 1)**.5
    
    return mu, std_vec

def grn_lstsq(mu, sigma2, movec, lectar):
    diffs = mu.dot(movec) - lectar
    return -.5 * np.sum(diffs**2 / sigma2)

def least_sq_fit(motif_vex, lectars):
    # motif_vex = M x G array of motif vectors
    # lectars = L x G NORMALIZED! array of lectin bindings
    # returns L x M matrix movec --> binding
    myfit = nla.lstsq(motif_vex.T, lectars.T, rcond = 10**-10)
    mat = myfit[0].T
    lectin_vars = np.mean( (mat.dot(motif_vex) - lectars)**2, axis = 1 )
    fig, (ax1, ax2) = plt.subplots(2)
    ax1.imshow(lectars)
    ax2.imshow(mat.dot(motif_vex))
    plt.show()
    return mat, lectin_vars


def markov_trainer(start, flow, motifs, grn_funk, N, delta):
    # flow uses some integer code for the motifs and codes for energy
    # will not alter the input flow and start
    
    S = len(start)
    flow = deepcopy(flow)
    starters, start_grns = zip(*start.items())
    start_grns = log(array(start_grns))
    
    xtart, xmat, x1 = get_motif_xpex(start, flow, motifs)
    
    grn1 = grn_funk(x1)
    watcher = []
    for a in range(N):
        prog_bar(a,N)
        pot_start_grns = start_grns + delta * (rand(S) - .5)
        lse = logsumexp(pot_start_grns)
        newstart = dict(zip( starters, exp(pot_start_grns-lse) ))
        
        newflow = deepcopy(flow)
        
        for link, futures in flow.items():
            if len(futures) > 1:
                counters, probs = zip(*futures.items())
                grn_hold = log(array(probs)) + delta * (rand(len(probs)) - .5)
                probs = exp(grn_hold - logsumexp(grn_hold))
                newflow[link] = dict(zip(counters, probs))
            elif len(futures) == 0:
                raise Exception('i dont actuyll think dis a problem, but heyoooooo')
        
        xtart, xmat, x2 = get_motif_xpex(newstart, newflow, motifs)
        grn2 = grn_funk(x2)
        
        if rand() > 1 / (1 + exp(grn2-grn1)):
            x1 = x2
            start_grns = pot_start_grns
            flow = newflow
            grn1 = grn2
            
        watcher.append(grn1)
        
    start = dict(zip( starters, exp(start_grns-logsumexp(start_grns)) ))
    
    plt.plot(watcher)
    plt.show()
        
    return start, flow, watcher

def minimu(sigmas, movex, lectarz):
    # for a SINGLE LECTIN
    # sigmas = M long stds NOT variances
    # movex = M x G
    # lectarz = G long array of lectin readouts
    M, G = movex.shape
    if len(lectarz.shape) != 1 or len(lectarz) != G:
        raise Exception(' lectarz shape mismatch')
    sigma_vec = sigmas.dot(movex)
    normed_movex = movex / sigma_vec
    normed_lectarz = lectarz / sigma_vec
    return sop.nnls(normed_movex.T, normed_lectarz)[0]

def starter(glycan_list, bindings, N):
    # glycan_list = cfg5_cut_trees
    # bindings = bojar_avgs
    tic()
    REPS = 10
    G = len(glycan_list)
    L = bindings.shape[0]
    if bindings.shape[1] != G:
        raise Exception(' lectarz shape mismatch')
    motif_list, motif_counts = zip(* get_motifs(glycan_list, forme = 'dict').items())
    M = len(motif_list)
    motif_tsil = {motif_list[i] : i for i in range(M)}
    motif_vex = get_motif_vector(glycan_list, motif_list, mode = 'multi')
    total_start = get_start_link_probs(glycan_list)
    total_flow = get_link_flow(glycan_list)
    '''
    restricted_motifs = []
    for motif, count in zip(motif_list, motif_counts):
        if count > 1:
            restricted_motifs.append(motif)
    restricted_motif_vex = []
    for tree in glycan_list:
        restricted_motif_vex.append(get_motif_vector(tree, restricted_motifs))
    restricted_motif_vex = array(restricted_motif_vex).T
    '''
    mu, std_vec = fit2(motif_vex, bindings)
    perf_mu, perf_std_vec = fit2(motif_vex, motif_vex + randn(M,G)*.001)
    
    guy = randint(G)
    guise, proxies = dumb_sampling(bindings[:,guy:guy+5], cfg5_cut_trees, mu, std_vec, N)
    perf_guise, perf_proxies = dumb_sampling(motif_vex[:,guy:guy+5], cfg5_cut_trees, perf_mu, perf_std_vec, N)
    
    gpimg(glycan_list[guy])
    plt.show()
    gpimg(perf_guise[0])
    gpimg(guise[0])
    plt.show()
        
    return guise, proxies

def swaggy_entropy(start, flow):
    link_list = list(flow.keys())
    link_tsil = {link : i for i, link in enumerate(link_list)}
    
    L = len(link_list)
    
    onestep = zeros(L)
    flomat = zeros((L,L))
    for link1, futures in flow.items():
        toss, probs = zip(*futures.items())
        onestep[link_tsil[link1]] = entropy(list(probs))
        for fut, p in futures.items():
            for link2 in fut.elements():
                flomat[link_tsil[link1], link_tsil[link2]] += p
    
    thing = nla.lstsq(eye(L)-flomat, onestep)
    
    S_link = thing[0]
    S = entropy(list(start.values()))
    for guy, p in start.items():
        S += p * S_link[link_tsil[guy]]
    
    return S




    